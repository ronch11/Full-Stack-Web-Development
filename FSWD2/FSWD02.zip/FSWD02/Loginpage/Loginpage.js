function SINGIN() {
    return window.location.assign("/signin/signin.html");
}

function SINGUP() {
    return window.location.assign("/signup/signup.html");
}